<?php
$wp_customize->add_section(
    'home_page_layout_options',
    array(
        'title'      => __( 'Front Page Sidebar Options', 'portfolioxpress' ),
        'panel'      => 'portfolioxpress_option_panel',
    )
);
